(()=>{
  const status=document.getElementById('live-status-local');
  async function request(type,data={}){
    try{const r=await chrome.runtime.sendMessage({type,...data});if(!r?.ok)throw Error(r?.error||'Falha na conexão.');
      const s=r.live;status.textContent=s.enabled?'Conectado ao assistente · '+(s.lastSync?'última sincronização '+new Date(s.lastSync).toLocaleTimeString():'aguardando sincronização')+(s.error?' · '+s.error:''):'Assistente local desconectado.';
    }catch(e){status.textContent=e.message;}
  }
  document.getElementById('live-link').onsubmit=e=>{e.preventDefault();const input=document.getElementById('live-token');request('LIVE_CONFIG',{enabled:true,token:input.value.trim()});input.value='';};
  document.getElementById('live-disconnect').onclick=()=>request('LIVE_CONFIG',{enabled:false});
  document.getElementById('live-sync').onclick=()=>request('LIVE_SYNC');
  document.querySelector('#local-assistant .help-link').onclick=e=>{e.preventDefault();request('LIVE_OPEN');};
  request('LIVE_INFO');setInterval(()=>request('LIVE_INFO'),10000);
})();
