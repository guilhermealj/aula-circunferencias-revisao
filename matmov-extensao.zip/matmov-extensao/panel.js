'use strict';
let snapshot=null,view=null,busy=false,refreshPending=false,limit=30,reviewId=null,settingsSession=null;
const initialSelectors={block:'.Ss4fHf',author:'.poVWob',time:'.MuzmKe',text:'[jsname="dTKtvb"]'};
const options=(items,value)=>items.map(([id,label])=>'<option value="'+esc(id)+'" '+(id===value?'selected':'')+'>'+esc(label)+'</option>').join('');
const qOptions=id=>options(LessonCore.QUESTIONS.map(q=>[q.id,q.id+' · '+q.title]),id);
const date=value=>value?new Date(value).toLocaleTimeString('pt-BR'):'—';
function participantLabel(p){const peers=(snapshot?.session.participants||[]).filter(x=>x.name===p.name);return p.name+(peers.length>1?' · conta '+(peers.findIndex(x=>x.id===p.id)+1)+' ['+p.id.slice(0,6)+']':'');}
function report(err){$('#error').hidden=false;$('#error').textContent=err.message||String(err);}
async function rpc(type,data={}){const response=await chrome.runtime.sendMessage({type,...data});if(!response?.ok)throw Error(response?.error||'A extensão não respondeu. Reabra o controle.');return response;}
function download(data,type,name){const url=URL.createObjectURL(new Blob([data],{type})),a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),3000);}
const fileDate=()=>new Date().toISOString().slice(0,10);
async function act(type,data={},message='Salvo.'){if(busy)return;busy=true;$('#error').hidden=true;document.body.setAttribute('aria-busy','true');try{const result=await rpc(type,data);if(result.snapshot)snapshot=result.snapshot;else snapshot=(await rpc('GET')).snapshot;if(message)toast(message);render(true);return result;}catch(e){report(e);try{snapshot=(await rpc('GET')).snapshot;render(true);}catch{}return null;}finally{busy=false;document.body.removeAttribute('aria-busy');}}
async function edit(fn){if(!view||busy)return;const before=structuredClone(view.session),after=structuredClone(before);fn(after);return act('PATCH',{before,after});}
// Análise do assistente local (vem na resposta da sincronização). Só vale para a sessão atual.
const ANALYSIS_KEY='matmov-aula12-local-analysis-v1';let liveAnalysis=null;
const auto=e=>liveAnalysis&&snapshot&&liveAnalysis.sessionId===snapshot.session.id?liveAnalysis.messages?.[e.id]||null:null;
function pending(e){return !e.ignored&&!e.reviewed&&!e.inactive&&auto(e)?.status!=='done';}
function loadAnalysis(){if(!chrome.storage?.local)return;chrome.storage.local.get(ANALYSIS_KEY).then(r=>{liveAnalysis=r?.[ANALYSIS_KEY]||null;if(snapshot){view=structuredClone(snapshot);renderReviews();}}).catch(()=>{});}
chrome.storage?.onChanged?.addListener((changes,area)=>{if(area==='local'&&changes[ANALYSIS_KEY])loadAnalysis();});
function record(s,pid){s.records[s.selected]??={};return s.records[s.selected][pid]??={participated:false,correct:LessonCore.question(s.selected).parts.map(()=>false),note:''};}
function dirty(s){s.complete=s.complete.filter(q=>q!==s.selected);}
function render(force=false){
  if(!snapshot)return;
  const cap=snapshot.capture,health=cap.health,active=snapshot.session.rounds.find(r=>r.id===snapshot.session.active),stale=!health||Date.now()-health.at>20000;
  $('#live-status').textContent=(cap.enabled?'Captura ativa':'Captura pausada')+' · '+(active?active.qid+' aberta':'rodada encerrada')+' · '+snapshot.totalEvents+' mensagens salvas'+(health?.pending?' · '+health.pending+' aguardando gravação':'')+(health?.error?' · Atenção: '+health.error:'');
  $('#connection-status').textContent=(cap.tabId!==null?'Meet vinculado · '+(stale?'sem sinal recente; recarregue o Meet':'observador conectado · '+health.blocks+' blocos / '+health.texts+' mensagens visíveis'):'Vincule a reunião.')+' | '+(snapshot.presentationTabId!==null?'Apresentação vinculada.':'Apresentação não vinculada.');
  $('#capture').textContent=cap.enabled?'Pausar captura':'Ativar captura';$('#capture').disabled=cap.tabId===null;$('#project').disabled=!!active;
  $('#diagnostic').textContent='Último sinal: '+date(health?.at)+' · última mensagem observada: '+date(health?.lastObserved)+(health?.error?' · '+health.error:'');
  if(!force&&(document.activeElement?.matches('input,textarea,select')||$('#review-dialog').open)){refreshPending=true;return;}
  refreshPending=false;view=structuredClone(snapshot);const s=view.session,q=LessonCore.question(s.selected),totals=LessonCore.totals(s),rows=Object.fromEntries(Object.entries(s.records[q.id]||{}).filter(([pid])=>s.participants.some(p=>p.id===pid&&p.active!==false)));
  $('#round-view').innerHTML='<label class="field">Questão<select id="question">'+qOptions(q.id)+'</select></label><p><span class="badge">'+(active?esc(active.qid)+' · aberta':'Rodada encerrada')+'</span></p><button id="round" class="primary" '+(s.omitted.includes(q.id)?'disabled':'')+'>'+(active?.qid===q.id?'Encerrar rodada':'Abrir rodada')+'</button><p class="small">Alt + Shift + Q também abre/encerra.</p><p class="small"><strong>Gabarito:</strong> '+esc(q.key)+'</p><p class="tiny">'+esc(q.parts.join(' · ')||'Somente participação')+'</p><label><input id="complete" type="checkbox" '+(s.complete.includes(q.id)?'checked':'')+'> Registro conferido</label><label><input id="omitted" type="checkbox" '+(s.omitted.includes(q.id)?'checked':'')+'> Questão não aplicada</label>';
  $('#question').onchange=e=>{const value=e.target.value;edit(s=>s.selected=value);};
  $('#round').onclick=()=>act('ROUND',{},'Rodada atualizada.');
  $('#complete').onchange=e=>{const value=e.target.checked;edit(s=>{dirty(s);if(value)s.complete.push(s.selected);});};
  $('#omitted').onchange=e=>{const value=e.target.checked;edit(s=>{s.omitted=s.omitted.filter(id=>id!==s.selected);if(value){s.omitted.push(s.selected);const r=s.rounds.find(r=>r.id===s.active);if(r?.qid===s.selected){r.closedAt=Date.now();s.active=null;}}});};
  if(s.aggregates[q.id]){const aggregate=s.aggregates[q.id],notice=document.createElement('div');notice.className='status warn';notice.innerHTML='<p class="tiny">Contagem coletiva importada: '+aggregate.attempts+' tentativas, '+aggregate.correct+' acertos. Ela prevalece na projeção coletiva.</p><button id="clear-aggregate">Usar registros individuais</button>';$('#round-view').append(notice);$('#clear-aggregate').onclick=()=>edit(s=>{delete s.aggregates[s.selected];dirty(s);});}
  const note=LessonMeta[view.slide],guide=items=>items?.length?'<p class="guide-label">O que explicar</p><ul class="guide">'+items.map(t=>'<li>'+esc(t)+'</li>').join('')+'</ul>':'';
  const open=$('#lesson-notes .full-guide')?.open;
  $('#lesson-notes').innerHTML=(note?'<span class="chip">Tela '+(view.slide+1)+'</span><h4>'+esc(note.title)+'</h4><p>'+esc(note.notes)+'</p>'+guide(note.guide):'')+'<details class="full-guide"'+(open?' open':'')+'><summary>Roteiro completo da aula</summary>'+LessonMeta.map((m,i)=>'<h4>'+String(i+1).padStart(2,'0')+' · '+esc(m.title)+'</h4>'+guide(m.guide)).join('')+'</details>';
  $('#notes').value=s.notes;
  $('#roster-status').textContent=s.participants.filter(p=>p.active!==false).length+' alunos ativos · '+s.participants.filter(p=>p.active===false).length+' desativados · última leitura: '+date(view.roster?.lastScanAt)+'. A lista pode ser parcial: abra Pessoas e role a lista no Meet.';
  $('#roster-list').innerHTML=s.participants.map(p=>'<label class="roster-person '+(p.active===false?'inactive':'')+'"><input type="checkbox" data-student="'+p.id+'" '+(p.active!==false?'checked':'')+'><span>'+esc(participantLabel(p))+'</span></label>').join('');
  $$('[data-student]').forEach(el=>el.onchange=()=>act('PARTICIPANT_ACTIVE',{pid:el.dataset.student,active:el.checked},el.checked?'Aluno ativado.':'Participante desativado; histórico preservado.'));
  const contextField=document.createElement('label');contextField.className='field';contextField.innerHTML='Contexto adicional da pergunta<textarea id="question-note" maxlength="4000" placeholder="Se reformular a pergunta oralmente, registre aqui antes de abrir a rodada.">'+esc(view.questionNotes?.[q.id]||'')+'</textarea><span class="tiny">Salvo com a próxima rodada. A extensão não transcreve sua voz.</span>';$('#round-view').append(contextField);
  $('#question-note').onchange=e=>act('QUESTION_NOTE',{qid:q.id,note:e.target.value});

  $('#unknown').innerHTML=view.unknown.map((name,i)=>'<div class="association" data-author-index="'+i+'"><strong>'+esc(name)+'</strong><select aria-label="Associar '+esc(name)+'">'+options([['','Escolha um participante'],...s.participants.map(p=>[p.id,participantLabel(p)])],'')+'</select><button data-link>Associar</button><button data-create>Cadastrar como novo</button><button data-ignore-author>Ignorar autor</button></div>').join('');
  $$('.association').forEach(el=>{const author=view.unknown[+el.dataset.authorIndex];$('[data-link]',el).onclick=()=>act('ASSOCIATE',{author,participantId:$('select',el).value});$('[data-create]',el).onclick=()=>act('ASSOCIATE',{author,create:true});$('[data-ignore-author]',el).onclick=()=>act('ASSOCIATE',{author,participantId:'ignore'});});
  $('#records').innerHTML='<div class="summary-grid"><div class="value">Tentativas em '+q.id+'<b>'+Object.values(rows).filter(r=>r.participated).length+'</b></div><div class="value">Acertos completos<b>'+(q.parts.length?Object.values(rows).filter(r=>r.participated&&r.correct.every(Boolean)).length:'—')+'</b></div><div class="value">Máximo da aula<b>'+LessonCore.maxScore(s)+'</b></div></div>'+(s.participants.length?'<div class="table-scroll"><table class="score-table"><thead><tr><th>Nome privado</th><th>Tentou</th><th>Componentes corretos</th><th>Observação</th><th>Total</th></tr></thead><tbody>'+s.participants.filter(p=>p.active!==false).map(p=>{const r=rows[p.id],manual=view.events.some(e=>e.qid===q.id&&e.participantId===p.id&&e.manual);return '<tr data-pid="'+p.id+'"><td><strong>'+esc(participantLabel(p))+'</strong>'+(manual?'<span class="manual-tag">Correção manual preservada</span>':'')+'<button class="small-button" data-unlock title="Substitui o registro desta questão pelas mensagens revisadas">Usar revisões do chat</button></td><td><input type="checkbox" data-edit="participated" aria-label="Participou · '+esc(participantLabel(p))+'" '+(r?.participated?'checked':'')+'></td><td><div class="checks">'+q.parts.map((part,i)=>'<label title="'+esc(part)+'"><input type="checkbox" data-edit="correct" data-part="'+i+'" aria-label="'+esc(part)+' · '+esc(participantLabel(p))+'" '+(r?.correct[i]?'checked':'')+'>'+(i+1)+'</label>').join('')+(q.parts.length?'':'Só participação')+'</div></td><td><input type="text" data-edit="note" maxlength="2000" aria-label="Observação · '+esc(participantLabel(p))+'" value="'+esc(r?.note||'')+'"></td><td>'+fmt(totals.find(t=>t.id===p.id).points)+'</td></tr>';}).join('')+'</tbody></table></div>':'<p class="empty">Abra Pessoas no Meet para cadastrar a turma automaticamente.</p>');
  $$('[data-edit]').forEach(el=>el.onchange=()=>{const pid=el.closest('[data-pid]').dataset.pid,kind=el.dataset.edit,value=el.type==='checkbox'?el.checked:el.value,part=+el.dataset.part;edit(s=>{const r=record(s,pid);if(kind==='correct'){r.correct[part]=value;if(value)r.participated=true;}else{r[kind]=value;if(kind==='participated'&&!value)r.correct.fill(false);}dirty(s);});});
  $$('[data-unlock]').forEach(el=>el.onclick=()=>{if(confirm('Recalcular esta questão pelas mensagens do chat? A correção manual será substituída.'))act('UNLOCK',{qid:q.id,pid:el.closest('[data-pid]').dataset.pid});});
  renderReviews();
  const labelsOpen=$('#public-labels details')?.open;
  $('#public-labels').innerHTML=s.participants.length?'<details '+(labelsOpen?'open':'')+'><summary>Escolher rótulos autorizados para projeção</summary><div class="table-scroll"><table class="score-table"><thead><tr><th>Exibir</th><th>Nome privado</th><th>Rótulo público</th></tr></thead><tbody>'+s.participants.filter(p=>p.active!==false).map(p=>'<tr data-label-pid="'+p.id+'"><td><input type="checkbox" data-publish aria-label="Autorizar '+esc(participantLabel(p))+'" '+(p.publish?'checked':'')+'></td><td>'+esc(participantLabel(p))+'</td><td><input data-label maxlength="100" aria-label="Rótulo de '+esc(participantLabel(p))+'" value="'+esc(p.label)+'"></td></tr>').join('')+'</tbody></table></div></details>':'<p class="small">Sem participantes selecionados; o resultado coletivo continua disponível.</p>';
  $$('[data-publish],[data-label]').forEach(el=>el.onchange=()=>{const pid=el.closest('[data-label-pid]').dataset.labelPid,isCheck=el.hasAttribute('data-publish'),value=isCheck?el.checked:el.value;edit(s=>{const p=s.participants.find(p=>p.id===pid);p[isCheck?'publish':'label']=value;});});
  // Ajustes não são reconstruídos durante digitação; somente o primeiro carregamento.
  if(!$('#selector-fields').children.length||settingsSession!==s.id){$('#selector-fields').innerHTML=Object.entries(cap.selectors).map(([key,value])=>'<label class="field">'+esc(key)+'<input data-selector="'+esc(key)+'" value="'+esc(value)+'" required maxlength="200"></label>').join('');$('#ignore-names').value=cap.ignoredNames.join('\n');settingsSession=s.id;}
}
function renderReviews(){
  if(!view)return;const filter=$('#review-filter').value,list=view.events.filter(e=>filter==='all'||(filter==='pending'?pending(e):e.qid===view.session.selected));
  $('#review-list').innerHTML=list.slice(0,limit).map(e=>{const p=view.session.participants.find(p=>p.id===e.participantId);const a=auto(e),status=e.ignored?'Ignorada':e.inactive?'Não aluno':e.reviewed?'Conferida':a?.status==='done'?'Analisada pelo assistente':a?.status==='review'?'Assistente pede conferência':a?'Aguardando assistente':'A revisar';return '<article class="message" data-event="'+esc(e.id)+'"><div class="message-meta">'+esc(e.qid||'Sem rodada')+' · '+date(e.observedAt)+' · '+esc(e.author)+(p?' → '+esc(participantLabel(p)):' · autor não associado')+' <span class="badge '+(pending(e)?'pending':'')+'">'+status+'</span></div><p class="message-text">'+esc(e.text)+'</p><p class="tiny">'+esc(a?.label||(a?'Aguardando a próxima análise automática.':e.reason||'Mensagem pendente de análise.'))+(a?.identityPending?' · autor ainda não associado':'')+'</p><div class="buttons"><button data-review>Conferir</button><button data-ignore-event '+(e.ignored?'disabled':'')+'>Não é resposta</button></div></article>';}).join('');
  $('#message-count').textContent=Math.min(limit,list.length)+' de '+list.length+' neste filtro · '+view.totalEvents+' no total';$('#more').hidden=list.length<=limit;
  $$('[data-review]').forEach(el=>el.onclick=()=>openReview(el.closest('[data-event]').dataset.event));
  $$('[data-ignore-event]').forEach(el=>el.onclick=()=>act('REVIEW',{review:{id:el.closest('[data-event]').dataset.event,action:'ignore'}}));
}
function reviewParts(values=[]){const q=LessonCore.question($('#review-question').value);$('#review-parts').innerHTML=q.parts.map((part,i)=>'<label><input type="checkbox" data-reviewed-part="'+i+'" '+(values[i]===true?'checked':'')+'>'+esc(part)+'</label>').join('')||(q.id==='Q1'?'<p>Estimativa: registra somente participação.</p>':'');}
function openReview(id){const e=snapshot.events.find(e=>e.id===id);reviewId=id;$('#review-source').textContent=e.author+': '+e.text;$('#review-participant').innerHTML=options([['','Selecione'],...snapshot.session.participants.filter(p=>p.active!==false).map(p=>[p.id,participantLabel(p)])],e.participantId);$('#review-question').innerHTML=qOptions(e.qid||snapshot.session.selected);reviewParts(e.forced||[]);$('#review-dialog').showModal();}
async function refreshTabs(){try{
  const tabs=await rpc('TABS');
  $('#extension-version').textContent='Extensão '+(tabs.version||'—');
  const hint=$('#lesson-hint');hint.hidden=tabs.lesson.length>0;
  hint.textContent=tabs.pageAccess===false?'O Chrome não concedeu acesso ao site da aula. Em chrome://extensions → MatMov → Detalhes → Acesso ao site, permita acesso aos arquivos locais da aula. Depois recarregue a guia da aula.':'Nenhuma aula encontrada neste perfil do Chrome. Abra aula12.html neste mesmo perfil e recarregue a guia após atualizar a extensão. A lista é atualizada automaticamente.';
  for(const kind of ['meet','lesson']){
    const el=$('#'+kind+'-tabs');if(document.activeElement===el)continue;
    const bound=kind==='meet'?snapshot?.capture.tabId:snapshot?.presentationTabId;
    const chosen=tabs[kind].some(t=>String(t.id)===el.value)?el.value:bound;
    el.innerHTML=options([['','Selecione uma guia'],...tabs[kind].map(t=>[String(t.id),t.title+' · '+t.url])],String(chosen));
  }
}catch(e){report(e);}}
async function update(){if(busy)return;try{snapshot=(await rpc('GET')).snapshot;render();}catch(e){report(e);}}
$('#refresh').onclick=async()=>{await update();await refreshTabs();};
$('#meet-form').onsubmit=e=>{e.preventDefault();act('BIND_MEET',{tabId:Number($('#meet-tabs').value)},'Meet vinculado. Ative a captura e abra o chat.');};
$('#lesson-form').onsubmit=e=>{e.preventDefault();act('BIND_LESSON',{tabId:Number($('#lesson-tabs').value)},'Apresentação vinculada.');};
$('#capture').onclick=()=>act('CAPTURE_SWITCH',{enabled:!snapshot.capture.enabled},'Captura atualizada.');
$('#focus-lesson').onclick=()=>act('FOCUS_LESSON',{},'');
$('#add').onsubmit=async e=>{e.preventDefault();const names=$('#names').value.split(/[,;\n]/).map(n=>n.trim()).filter(Boolean);const result=await edit(s=>{for(const name of names){if(name.length>100||s.participants.some(p=>p.name.toLocaleLowerCase()===name.toLocaleLowerCase())||s.participants.length>=500)continue;s.participants.push({id:LessonCore.uid(),name,label:name.split(' ')[0],publish:false});}});if(result)$('#names').value='';};
$('#notes').onchange=e=>{const value=e.target.value;edit(s=>s.notes=value);};
$('#review-filter').onchange=()=>{limit=30;view=structuredClone(snapshot);renderReviews();};$('#more').onclick=()=>{limit+=30;renderReviews();};
$('#review-question').onchange=()=>reviewParts();$('#close-review').onclick=()=>{$('#review-dialog').close();render(true);};
$('#review-form').onsubmit=async e=>{e.preventDefault();const result=await act('REVIEW',{review:{id:reviewId,qid:$('#review-question').value,participantId:$('#review-participant').value,correct:$$('[data-reviewed-part]').map(el=>el.checked)}});if(result)$('#review-dialog').close();};
$('#export').onclick=async()=>{try{const result=await rpc('EXPORT');download(JSON.stringify(result.backup,null,2),'application/json','matmov-backup-'+fileDate()+'.json');toast('Backup completo gerado.');}catch(e){report(e);}};
$('#export-session').onclick=()=>download(JSON.stringify(snapshot.session,null,2),'application/json','matmov-sessao-'+fileDate()+'.json');
$('#csv').onclick=()=>download(LessonCore.toCSV(snapshot.session),'text/csv;charset=utf-8','matmov-pontos-'+fileDate()+'.csv');
$('#import').onclick=()=>$('#import-file').click();$('#import-file').onchange=async e=>{const file=e.target.files[0];if(!file)return;try{if(file.size>20_000_000)throw Error('Arquivo maior que 20 MB.');const data=JSON.parse(await file.text());if(confirm('Restaurar este JSON? A sessão atual ficará em “Recuperar anterior”.'))await act('IMPORT',{data},'Sessão restaurada, com captura pausada.');}catch(err){report(err);}e.target.value='';};
$('#new').onclick=()=>{if(confirm('Iniciar uma sessão vazia? A atual ficará em “Recuperar anterior”. Exporte o backup para guardar mais aulas.'))act('NEW',{},'Nova sessão. Vincule o Meet novamente.');};
$('#previous').onclick=()=>{if(confirm('Trocar para a sessão anterior? A atual ficará recuperável no mesmo botão.'))act('RESTORE_PREVIOUS',{},'Sessão anterior recuperada.');};
$('#project').onclick=()=>act('PROJECT',{mode:$('#public-mode').value},'Resultado enviado à apresentação.');$('#hide').onclick=()=>act('HIDE',{},'Resultado recolhido.');
$('#selector-form').onsubmit=e=>{e.preventDefault();const selectors=Object.fromEntries($$('[data-selector]').map(el=>[el.dataset.selector,el.value]));try{for(const v of Object.values(selectors))document.querySelector(v);}catch{report(Error('Há um seletor CSS inválido.'));return;}act('SELECTORS',{selectors},'Seletores atualizados. Confira o diagnóstico e reative a captura.');};
$('#default-selectors').onclick=()=>{for(const el of $$('[data-selector]'))el.value=initialSelectors[el.dataset.selector];};
$('#ignore-form').onsubmit=e=>{e.preventDefault();act('IGNORED_NAMES',{names:$('#ignore-names').value.split('\n').map(n=>n.trim()).filter(Boolean)});};
chrome.runtime.onMessage.addListener(m=>{if(m?.type==='STATE_CHANGED')update();});
document.addEventListener('focusout',()=>{setTimeout(()=>{if(refreshPending&&!busy)render();},150);});
window.addEventListener('focus',()=>{if(!busy)refreshTabs();});
setInterval(()=>{if(snapshot)render();if(!busy)refreshTabs();},10000);
(async()=>{await update();loadAnalysis();await refreshTabs();})().catch(report);

$('#read-roster').onclick=()=>act('READ_ROSTER',{},'Lista lida. Confira os nomes encontrados; se faltarem alunos, abra Pessoas no Meet e role a lista.');
$('#export-messages').onclick=async()=>{try{const result=await rpc('EXPORT_MESSAGES');download(JSON.stringify(result.dataset,null,2),'application/json','matmov-mensagens-contexto-'+fileDate()+'.json');toast('Mensagens e contexto exportados.');}catch(e){report(e);}};
