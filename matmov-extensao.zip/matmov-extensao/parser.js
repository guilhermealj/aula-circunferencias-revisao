'use strict';
/* Auxílio conservador para formatos objetivos. Mensagens livres continuam sob revisão. */
const MatMovParser=(()=>{
  const norm=s=>String(s).normalize('NFD').replace(/[\u0300-\u036f]/g,'').trim().toLowerCase().replace(/\s+/g,' ');
  function prefix(text){
    const raw=String(text).trim(),m=raw.match(/^q([1-9])(?=$|[\s:.)-]|[abc](?=[:)\s-]))/i);
    if(!m)return {qid:null,part:null,text:raw};
    let rest=raw.slice(m[0].length).replace(/^\s*[:.)-]?\s*/,''),part=null;
    const c=rest.match(/^([abc123])\s*[:)-]\s*(.*)$/i)||rest.match(/^([abc])\s+(.*)$/i);
    if(c){part={a:0,b:1,c:2,'1':0,'2':1,'3':2}[c[1].toLowerCase()];rest=c[2];}return {qid:'Q'+m[1],part,text:rest};
  }
  function number(text,unit=''){
    const m=norm(text).replace(/^(?:x|d|r|c|alpha|alfa|central|inscrito|circunscrito)\s*[:=]\s*/,'').replace(/[.!]$/,'').match(/^(-?\d+(?:[.,]\d+)?)\s*(cm|m|metros?|centimetros?|°|graus?|rad)?$/);
    if(!m)return null;let n=Number(m[1].replace(',','.')),u=m[2]||'';if(!Number.isFinite(n))return null;
    if(unit==='cm'){if(/^m(?:etros?)?$/.test(u))n*=100;else if(u&&!/^(cm|centimetros?)$/.test(u))return null;}
    else if(unit==='deg'){if(u&&!/^(°|graus?)$/.test(u))return null;}
    else if(unit==='rad'){if(u&&u!=='rad')return null;}
    else if(u)return null;return n;
  }
  function piCoefficient(text,unit='rad'){
    let s=norm(text).replace(/\s+/g,'').replace(/radianos?$/,'rad');const suffix=unit==='cm'?'(?:cm)?':'(?:rad)?';
    const m=s.match(new RegExp('^(\\d+(?:[.,]\\d+)?)?(?:π|pi)(?:/(\\d+))?'+suffix+'$'));
    if(!m)return null;const n=Number((m[1]||'1').replace(',','.')),d=Number(m[2]||'1');return d>0&&Number.isFinite(n)?n/d:null;
  }
  const near=(a,b,t=1e-7)=>a!==null&&Math.abs(a-b)<t;
  const checks={
    Q2:[s=>{const n=number(s,'cm');return n===null?null:near(n,8);},s=>{const n=number(s,'cm');return n===null?null:near(n,6);}],
    Q3:[s=>{const p=piCoefficient(s,'cm'),n=number(s,'cm');return p!==null?near(p,10):n!==null?near(n,10*Math.PI,.03):null;}],
    Q4:[s=>{const p=piCoefficient(s);return p===null?null:near(p,1/3);},s=>{const n=number(s,'deg');return n===null?null:near(n,150);}],
    Q5:[s=>{const n=norm(s);return /^(igual|fica igual|permanece igual|constante|permanece constante|aumenta|diminui)$/.test(n)?!/(aumenta|diminui)/.test(n):null;},s=>{const n=number(s,'deg');return n===null?null:near(n,60);},s=>/^(?:o )?mesmo arco(?: observado| ab)?$/.test(norm(s))?true:null],
    Q6:[s=>{const n=number(s);return n===null?null:near(n,15);},s=>{const n=number(s,'deg');return n===null?null:near(n,70);}],
    Q7:[s=>{const n=number(s,'deg');return n===null?null:near(n,100);}],
    Q8:[s=>{const n=number(s,'deg');return n===null?null:near(n,92);},s=>{const n=number(s,'deg');return n===null?null:near(n,88);}],
    Q9:[s=>{const n=number(s,'deg');return n===null?null:near(n,70);},s=>{const p=piCoefficient(s);return p===null?null:near(p,1/2);},s=>{const n=number(s,'deg');return n===null?null:near(n,60);}]
  };
  function parse(text,qid,part=null){
    const size=qid==='Q1'?0:checks[qid]?.length,r={recognized:false,participated:false,correct:Array.from({length:size||0},()=>null),reason:'Formato livre; revisar.',raw:String(text)};
    if(size===undefined)return r;const p=prefix(text);if(p.qid&&p.qid!==qid)return {...r,reason:'Prefixo de outra questão.'};if(p.part!==null)part=p.part;
    if(part!==null&&(!Number.isInteger(part)||part<0||part>=size))return r;
    if(/^(nao sei|nao entendi|tenho duvida|\?)[.!]?$/.test(norm(p.text)))return {...r,recognized:true,participated:true,reason:'Dúvida declarada.'};
    if(qid==='Q1')return p.text.trim()?{...r,recognized:true,participated:true,reason:'Exemplo aberto; sem gabarito.'}:r;
    const pieces=p.text.includes(';')?p.text.split(';').map(x=>x.trim()):p.text.split(/\s+e\s+/i).map(x=>x.trim());
    const put=(i,s)=>{const correct=checks[qid][i](s);if(correct!==null){r.correct[i]=correct;r.recognized=r.participated=true;r.reason='Componente objetivo reconhecido; revisão disponível.';}};
    if(part!==null)put(part,p.text);else if(size===1)put(0,p.text);else if(pieces.length===size)pieces.forEach((s,i)=>put(i,s));return r;
  }
  return {norm,prefix,number,piCoefficient,parse};
})();
if(typeof module!=='undefined'&&module.exports)module.exports=MatMovParser;
