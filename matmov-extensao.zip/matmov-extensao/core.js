'use strict';
const LessonCore = (() => {
  const QUESTIONS = [
  {
    "id": "Q1",
    "title": "Circunferência em todo lugar",
    "parts": [],
    "key": "Exemplo e parte do objeto; resposta aberta",
    "slide": 1
  },
  {
    "id": "Q2",
    "title": "Raio, diâmetro e maior corda",
    "parts": [
      "Diâmetro 8 cm",
      "Maior corda: diâmetro"
    ],
    "key": "8 cm; diâmetro",
    "slide": 4
  },
  {
    "id": "Q3",
    "title": "Comprimento da circunferência",
    "parts": [
      "Contorno 10π cm"
    ],
    "key": "10π cm; aproximadamente 31,4 cm com π≈3,14",
    "slide": 8
  },
  {
    "id": "Q4",
    "title": "Graus e radianos",
    "parts": [
      "60° = π/3 rad",
      "5π/6 rad = 150°"
    ],
    "key": "π/3 rad; 150°",
    "slide": 13
  },
  {
    "id": "Q5",
    "title": "Cinema dos ângulos",
    "parts": [
      "Ângulo constante",
      "Inscrito 60°",
      "Mesmo arco observado"
    ],
    "key": "Permanece igual; 60°; mantém o mesmo arco AB",
    "slide": 18
  },
  {
    "id": "Q6",
    "title": "Apostila 1: x e arco",
    "parts": [
      "x = 15",
      "Arco AB = 70°"
    ],
    "key": "x=15; arco AB=70°",
    "slide": 24
  },
  {
    "id": "Q7",
    "title": "Apostila 5: semicircunferência",
    "parts": [
      "Arco AC = 100°"
    ],
    "key": "100°",
    "slide": 25
  },
  {
    "id": "Q8",
    "title": "Apostila 7: inscrito e tangentes",
    "parts": [
      "Central 92°",
      "Circunscrito 88°"
    ],
    "key": "92°; 88°",
    "slide": 30
  },
  {
    "id": "Q9",
    "title": "Saída individual",
    "parts": [
      "Inscrito 70°",
      "90° = π/2 rad",
      "Circunscrito 60°"
    ],
    "key": "70°; π/2 rad; 60°",
    "slide": 34
  }
];
  const uid=()=>typeof crypto!=='undefined'&&crypto.randomUUID?crypto.randomUUID():'id-'+Date.now()+'-'+Math.random().toString(36).slice(2);
  function fresh(){return {version:1,id:uid(),createdAt:Date.now(),title:'Aula 12 · Circunferências',participants:[],records:{},omitted:[],rounds:[],active:null,complete:[],aggregates:{},notes:'',selected:'Q1'};}
  const question=id=>QUESTIONS.find(q=>q.id===id);
  function score(record,q){if(!record||!record.participated)return 0;return 1+(q.parts.length?record.correct.filter(Boolean).length/q.parts.length:0);}
  function totals(state){return state.participants.map(p=>({id:p.id,label:p.label||p.name,name:p.name,publish:p.publish,active:p.active!==false,points:p.active===false?0:QUESTIONS.reduce((n,q)=>n+(state.omitted.includes(q.id)?0:score(state.records[q.id]?.[p.id],q)),0),count:QUESTIONS.filter(q=>!state.omitted.includes(q.id)&&state.records[q.id]?.[p.id]?.participated).length})).sort((a,b)=>b.points-a.points||a.label.localeCompare(b.label,'pt-BR'));}
  function maxScore(state){return QUESTIONS.reduce((n,q)=>n+(state.omitted.includes(q.id)?0:q.parts.length?2:1),0);}
  function validate(s){
    if(!s||s.version!==1||typeof s.id!=='string'||!Array.isArray(s.participants)||s.participants.length>500||!s.records||Array.isArray(s.records))throw Error('Formato de sessão inválido.');
    if(!Array.isArray(s.omitted)||!Array.isArray(s.complete)||!Array.isArray(s.rounds)||s.rounds.length>1000)throw Error('Rodadas ou questões inválidas.');
    for(const list of [s.omitted,s.complete])if(list.some(id=>!question(id)))throw Error('Questão desconhecida.');
    const ids=new Set();
    for(const p of s.participants){
      if(typeof p.id!=='string'||!/^[-\w]{1,100}$/.test(p.id)||['__proto__','constructor','prototype'].includes(p.id)||ids.has(p.id)||typeof p.name!=='string'||!p.name.trim()||p.name.length>100||typeof p.label!=='string'||p.label.length>100||typeof p.publish!=='boolean'||(p.active!==undefined&&typeof p.active!=='boolean'))throw Error('Cadastro de participante inválido.');
      ids.add(p.id);
    }
    for(const [qid,rows] of Object.entries(s.records)){
      const q=question(qid);if(!q||!rows||typeof rows!=='object'||Array.isArray(rows))throw Error('Questão inválida.');
      for(const [pid,r] of Object.entries(rows)){
        if(!ids.has(pid)||!r||typeof r.participated!=='boolean'||!Array.isArray(r.correct)||r.correct.length!==q.parts.length||r.correct.some(x=>typeof x!=='boolean')||typeof r.note!=='string'||r.note.length>2000)throw Error('Resposta inválida.');
      }
    }
    for(const r of s.rounds)if(!r||typeof r.id!=='string'||!question(r.qid)||!Number.isFinite(r.openedAt)||(r.closedAt!==null&&(!Number.isFinite(r.closedAt)||r.closedAt<r.openedAt)))throw Error('Rodada inválida.');
    if(s.active!==null&&!s.rounds.some(r=>r.id===s.active&&r.closedAt===null))throw Error('Rodada ativa inválida.');
    if(typeof s.notes!=='string'||s.notes.length>10000||!question(s.selected)||typeof s.title!=='string'||s.title.length>200)throw Error('Metadados inválidos.');
    if(!s.aggregates||typeof s.aggregates!=='object'||Array.isArray(s.aggregates))throw Error('Agregados inválidos.');
    for(const [qid,a] of Object.entries(s.aggregates))if(!question(qid)||!Number.isInteger(a.attempts)||a.attempts<0||a.attempts>500||!Number.isInteger(a.correct)||a.correct<0||a.correct>a.attempts)throw Error('Contagem coletiva inválida.');
    return s;
  }
  function publicData(s,mode){
    const q=question(s.selected),activeIds=new Set(s.participants.filter(p=>p.active!==false).map(p=>p.id)),records=Object.fromEntries(Object.entries(s.records[q.id]||{}).filter(([pid])=>activeIds.has(pid))),agg=s.aggregates[q.id];
    const attempts=agg?agg.attempts:Object.values(records).filter(r=>r.participated).length;
    const correct=agg?agg.correct:Object.values(records).filter(r=>r.participated&&q.parts.length&&r.correct.every(Boolean)).length;
    const result={qid:q.id,title:q.title,attempts,correct,hasAnswer:q.parts.length>0,partial:!s.complete.includes(q.id),mode,possible:maxScore(s),ranking:[],series:[]};
    if(mode!=='collective')result.partial=QUESTIONS.some(item=>!s.omitted.includes(item.id)&&(s.records[item.id]||s.aggregates[item.id]||s.rounds.some(r=>r.qid===item.id))&&!s.complete.includes(item.id));
    if(mode==='ranking')result.ranking=totals(s).filter(p=>p.publish&&p.active!==false).map(p=>({label:p.label,points:p.points}));
    if(mode==='lines')result.series=s.participants.filter(p=>p.publish&&p.active!==false).slice(0,4).map(p=>({label:p.label,values:QUESTIONS.reduce((a,item)=>{a.push((a.at(-1)||0)+(s.omitted.includes(item.id)?0:score(s.records[item.id]?.[p.id],item)));return a;},[])}));
    return result;
  }
  const csvCell=value=>'"'+String(value??'').replace(/^[\s]*[=+\-@]/,m=>"'"+m).replace(/"/g,'""')+'"';
  function toCSV(s){const rows=[['Sessão','Participante','Questão','Aplicada','Participou','Componentes corretos','Componentes','Pontos','Observação']];for(const p of s.participants.filter(p=>p.active!==false))for(const q of QUESTIONS){const r=s.records[q.id]?.[p.id];rows.push([s.title,p.name,q.id,!s.omitted.includes(q.id)?'sim':'não',r?.participated?'sim':'não',r?.correct.filter(Boolean).length||0,q.parts.length,s.omitted.includes(q.id)?0:score(r,q),r?.note||'']);}return '\ufeff'+rows.map(row=>row.map(csvCell).join(';')).join('\r\n');}
  return {QUESTIONS,question,uid,fresh,score,totals,maxScore,validate,publicData,toCSV};
})();
if(typeof module!=='undefined'&&module.exports)module.exports=LessonCore;
const $=(selector,root=document)=>root.querySelector(selector);
const $$=(selector,root=document)=>Array.from(root.querySelectorAll(selector));
const fmt=(n,d=1)=>Number(n).toLocaleString('pt-BR',{maximumFractionDigits:d});
const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function toast(message){const t=$('#toast');t.textContent=message;t.classList.add('show');clearTimeout(toast.timer);toast.timer=setTimeout(()=>t.classList.remove('show'),5000);}
