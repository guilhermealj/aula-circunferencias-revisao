(()=>{
  'use strict';
  const channel='matmov-aula12-extension-v1';
  const post=(type,payload)=>window.postMessage({channel,direction:'extension-to-page',type,payload},'*');
  window.addEventListener('message',async e=>{
    if(e.source!==window||e.data?.channel!==channel||e.data.direction!=='page-to-extension')return;
    const {type,payload}=e.data;
    const types={hello:'LESSON_HELLO',open:'LESSON_OPEN',slide:'LESSON_SLIDE',reveal:'LESSON_REVEAL',chart:'LESSON_CHART'};
    if(!types[type])return;
    const request={type:types[type]};
    if(type==='slide'){request.index=payload?.index;request.cardIndex=payload?.cardIndex;request.visibleContext=payload?.visibleContext;request.extraQuestion=payload?.extraQuestion;request.extraRevealed=payload?.extraRevealed;}
    if(type==='reveal')request.qid=payload?.qid;
    try{const result=await chrome.runtime.sendMessage(request);if(type==='chart'){post('live-chart',result?.ok?result.chart:{error:result?.error||'Gráfico indisponível.'});return;}if(result?.ok){if(type==='hello')post('extension-ready',{bound:result.bound});}else if(type==='open')post('extension-error',{message:result?.error||'Não foi possível abrir o controle.'});}
    catch{if(type==='chart')post('live-chart',{error:'Atualize a extensão e recarregue a aula. Confira se o assistente local está rodando.'});if(type==='open')post('extension-error',{message:'Extensão recarregada. Atualize esta guia.'});}
  });
  chrome.runtime.onMessage.addListener((m,_sender,respond)=>{
    if(m?.type==='BRIDGE_PING'){post('control-ready',{});respond({ok:true});}
    if(m?.type==='LESSON_MESSAGE'&&['public','hide-public','live-mode','chat'].includes(m.kind)){post(m.kind,m.payload);respond({ok:true});}
  });
  // A apresentação também envia hello: cobre ambas as ordens de carregamento.
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',()=>post('extension-ready',{}),{once:true});else post('extension-ready',{});
})();
