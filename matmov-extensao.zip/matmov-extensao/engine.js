'use strict';
const MatMovEngine=(()=>{
  const Core=typeof LessonCore!=='undefined'?LessonCore:require('../src/core.js');
  const Questions=typeof MatMovQuestions!=='undefined'?MatMovQuestions:require('./questions.js');
  const norm=s=>String(s).normalize('NFD').replace(/[\u0300-\u036f]/g,'').trim().toLowerCase().replace(/\s+/g,' ');
  const DEFAULT_SELECTORS={block:'.Ss4fHf',author:'.poVWob',time:'.MuzmKe',text:'[jsname="dTKtvb"]'};
  function fresh(){return {schema:1,captureMode:'free-text-v1',revision:0,session:Core.fresh(),capture:{enabled:false,tabId:null,meetUrl:'',resetToken:Core.uid(),selectors:{...DEFAULT_SELECTORS},ignoredNames:[],health:null},presentationTabId:null,slide:0,cardIndex:null,events:[],receipts:[],aliases:{},manual:{},roster:{identities:{},lastScanAt:null,visibleCount:0},questionNotes:{}};}
  function upgrade(store){
    if(store.captureMode!=='free-text-v1'){
      // Migração preserva resultados anteriores sem continuar a correção por formato.
      for(const [qid,rows] of Object.entries(store.session.records))for(const pid of Object.keys(rows))store.manual[qid+'|'+pid]=true;
      for(const e of store.events)e.legacy=true;
      store.captureMode='free-text-v1';
    }
    store.roster??={identities:{},lastScanAt:null,visibleCount:0};store.questionNotes??={};store.cardIndex??=null;
    return store;
  }
  function aliasKey(author){return 'name:'+norm(author);}
  function identify(store,author,authorMeetId=null){
    if(authorMeetId){const pid=store.roster?.identities?.['meet:'+JSON.stringify([store.capture.meetUrl,authorMeetId])];if(pid&&store.session.participants.some(p=>p.id===pid))return pid;}
    const key=aliasKey(author),mapped=store.aliases[key];if(mapped==='ignore')return null;
    const matches=store.session.participants.filter(p=>norm(p.name)===norm(author));
    if(matches.length>1)return null;
    if(mapped&&store.session.participants.some(p=>p.id===mapped))return mapped;
    return matches.length===1?matches[0].id:null;
  }
  function questionContext(store,qid){const q=Core.question(qid);return q?{...Questions.get(qid),title:q.title,components:[...q.parts],expectedAnswer:q.key,teacherNote:store.questionNotes?.[qid]||''}:null;}
  function syncRoster(store,entries,now=Date.now()){
    upgrade(store);
    if(!Array.isArray(entries)||entries.length>500)throw Error('Lista de participantes inválida.');
    for(const e of entries)if(!e||typeof e.name!=='string'||!e.name.trim()||e.name.length>100||(e.id!==null&&(typeof e.id!=='string'||!e.id||e.id.length>500)))throw Error('Participante do Meet inválido.');
    const group=new Map();for(const e of entries){const key=norm(e.name);group.set(key,(group.get(key)||0)+1);}
    const keyOf=entry=>'meet:'+JSON.stringify([store.capture.meetUrl,entry.id||'name:'+norm(entry.name)]);
    // Reserva apenas quem já está ligado a uma entrada visível agora. O Meet troca data-participant-id a cada
    // reentrada, então chaves antigas da mesma pessoa não podem impedir o reaproveitamento: era isso que fazia
    // cada recarregamento da aba do Meet criar outro participante com o mesmo nome.
    const claimed=new Set();
    for(const entry of entries){const bound=store.roster.identities[keyOf(entry)];if(bound)claimed.add(bound);}
    let added=0;
    for(const entry of entries){
      const key=keyOf(entry);
      let p=store.session.participants.find(p=>p.id===store.roster.identities[key]);
      if(!p){
        const free=store.session.participants.filter(p=>norm(p.name)===norm(entry.name)&&!claimed.has(p.id));
        // O nome precisa ser único entre os visíveis: homônimos simultâneos continuam sendo pessoas distintas.
        if(group.get(norm(entry.name))===1&&free.length===1&&store.session.participants.filter(p=>norm(p.name)===norm(entry.name)).length===1)p=free[0];
        if(!p){if(store.session.participants.length>=500)break;p={id:Core.uid(),name:entry.name.trim(),label:entry.name.trim().split(' ')[0],publish:false,active:true};store.session.participants.push(p);added++;}
        if(Object.keys(store.roster.identities).length>=1500)throw Error('Limite de identificadores atingido. Exporte e inicie outra sessão.');
        store.roster.identities[key]=p.id;claimed.add(p.id);
      }
      // Nunca reativa um não aluno desmarcado pelo professor.
    }
    store.roster.lastScanAt=now;store.roster.visibleCount=entries.length;recalculate(store);return {added};
  }
  function recalculate(store){
    const s=store.session,auto={};
    for(const e of [...store.events].sort((a,b)=>a.observedAt-b.observedAt||a.order-b.order)){
      if(e.ignored||!e.qid||!Core.question(e.qid))continue;
      const pid=e.participantId||identify(store,e.author,e.authorMeetId);
      if(!pid||!s.participants.some(p=>p.id===pid&&p.active!==false)||!e.reviewed||!e.forced)continue;
      auto[e.qid]??={};auto[e.qid][pid]??={participated:false,correct:Core.question(e.qid).parts.map(()=>false),note:''};
      const row=auto[e.qid][pid];row.participated=true;e.forced.forEach((v,i)=>{row.correct[i]=v;});
    }
    // Campos editados pelo professor prevalecem sobre novas sugestões automáticas.
    for(const [qid,rows] of Object.entries(auto))for(const [pid,row] of Object.entries(rows)){
      s.records[qid]??={};if(!store.manual[qid+'|'+pid])s.records[qid][pid]={...row,note:s.records[qid][pid]?.note||''};
    }
    // Remove somente registros automáticos sem evidência elegível; preserva todos os manuais.
    for(const [qid,rows] of Object.entries(s.records))for(const pid of Object.keys(rows))if(!store.manual[qid+'|'+pid]&&!auto[qid]?.[pid]&&s.participants.find(p=>p.id===pid)?.active!==false)delete rows[pid];
    return store;
  }
  function ingest(store,raw,now=Date.now()){
    if(!raw||typeof raw.id!=='string'||!/^[-\w:]{1,180}$/.test(raw.id)||typeof raw.author!=='string'||!raw.author.trim()||raw.author.length>100||typeof raw.text!=='string'||!raw.text.trim()||raw.text.length>20000||!Number.isFinite(raw.observedAt)||Math.abs(now-raw.observedAt)>3600000)throw Error('Evento de captura inválido.');
    if(store.receipts.includes(raw.id))return {duplicate:true};
    if(raw.part!=null&&(!Number.isInteger(raw.part)||raw.part<0||raw.part>2))throw Error('Componente inválido.');
    if(store.events.length>=5000||store.receipts.length>=10000){store.capture.enabled=false;return {limit:true};}
    store.receipts.push(raw.id);
    if(store.capture.ignoredNames.some(n=>norm(n)===norm(raw.author)))return {ignored:true};
    const hinted=store.session.rounds.find(r=>r.id===raw.roundId);
    const eligible=hinted&&raw.observedAt>=hinted.openedAt&&(hinted.closedAt===null||raw.observedAt<hinted.closedAt);
    const qid=hinted?.qid||null,quality=raw.quality==='live'&&(!hinted||eligible)?'live':'uncertain';
    const context=hinted?.context||questionContext(store,qid);
    const e={id:raw.id,order:store.events.length,author:raw.author.trim(),authorMeetId:typeof raw.authorMeetId==='string'&&raw.authorMeetId.length<=500?raw.authorMeetId:null,text:raw.text,observedAt:raw.observedAt,displayTime:String(raw.displayTime||'').slice(0,30),roundId:hinted?.id||null,qid,part:null,quality,reason:qid?'Mensagem livre da rodada; relação com a pergunta ainda não avaliada.':'Mensagem fora de rodada; associação à pergunta ainda não avaliada.',reviewed:false,ignored:false,questionContext:context?structuredClone(context):null,contextSource:hinted?.context?'round-snapshot':qid?'catalog-at-receipt':'none',slideIndex:Number.isInteger(raw.slideIndex)&&raw.slideIndex>=0&&raw.slideIndex<26?raw.slideIndex:null,cardIndex:Number.isInteger(raw.cardIndex)&&raw.cardIndex>=0&&raw.cardIndex<3?raw.cardIndex:null,truncated:raw.truncated===true};
    store.events.push(e);store.session.complete=store.session.complete.filter(id=>id!==qid);return {stored:true,id:e.id};
  }
  function patch(store,before,after){
    Core.validate(before);Core.validate(after);
    if(before.id!==store.session.id||after.id!==before.id)throw Error('A sessão mudou. Atualize o controle.');
    const roots=['selected','notes','complete','omitted','participants','aggregates','rounds','active','title'];
    const same=(a,b)=>JSON.stringify(a)===JSON.stringify(b);
    for(const field of roots)if(!same(before[field],after[field])){
      if(!same(before[field],store.session[field]))throw Error('Outro evento alterou '+field+'. Atualize e repita a alteração.');
      store.session[field]=structuredClone(after[field]);
    }
    for(const q of Core.QUESTIONS){
      const oldRows=before.records[q.id]||{},newRows=after.records[q.id]||{};
      for(const pid of new Set([...Object.keys(oldRows),...Object.keys(newRows)])){
        if(same(oldRows[pid],newRows[pid]))continue;
        if(!same(oldRows[pid],store.session.records[q.id]?.[pid]))throw Error('Chegou outra resposta desse aluno. Confira e repita a correção.');
        store.session.records[q.id]??={};
        if(newRows[pid]){store.session.records[q.id][pid]=structuredClone(newRows[pid]);store.manual[q.id+'|'+pid]=true;}
        else{delete store.session.records[q.id][pid];delete store.manual[q.id+'|'+pid];}
      }
    }
    Core.validate(store.session);recalculate(store);return store;
  }
  function review(store,{id,qid,participantId,action,correct}){
    const e=store.events.find(e=>e.id===id);if(!e)throw Error('Mensagem não encontrada.');
    const previousQid=e.qid;
    if(action==='ignore'){e.ignored=true;e.reviewedAt=Date.now();store.session.complete=store.session.complete.filter(id=>id!==previousQid);recalculate(store);return;}
    if(!Core.question(qid)||!store.session.participants.some(p=>p.id===participantId&&p.active!==false))throw Error('Escolha questão e aluno ativo válidos.');
    if(!Array.isArray(correct)||correct.length!==Core.question(qid).parts.length||correct.some(v=>typeof v!=='boolean'))throw Error('Marque os componentes corretos.');
    e.qid=qid;e.participantId=participantId;e.reviewed=true;e.ignored=false;e.forced=correct;e.reviewedAt=Date.now();
    store.session.complete=store.session.complete.filter(id=>id!==qid&&id!==previousQid);recalculate(store);
  }
  function associate(store,author,pid,create=false){
    if(typeof author!=='string'||!author.trim()||author.length>100)throw Error('Nome inválido.');
    const matches=store.session.participants.filter(p=>norm(p.name)===norm(author));
    if(pid!=='ignore'&&(matches.length>1||create&&matches.length))throw Error('Nome já cadastrado ou ambíguo. Identifique cada mensagem em Conferir ou no assistente local.');
    if(create){const p={id:Core.uid(),name:String(author).slice(0,100),label:String(author).split(' ')[0].slice(0,100),publish:false};if(store.session.participants.length>=500)throw Error('Limite de participantes atingido.');store.session.participants.push(p);pid=p.id;}
    if(pid!=='ignore'&&!store.session.participants.some(p=>p.id===pid))throw Error('Participante inválido.');
    store.aliases[aliasKey(author)]=pid;recalculate(store);
    const affected=new Set(store.events.filter(e=>aliasKey(e.author)===aliasKey(author)).map(e=>e.qid));store.session.complete=store.session.complete.filter(id=>!affected.has(id));
  }
  function snapshot(store){
    return {revision:store.revision,session:store.session,capture:store.capture,roster:store.roster,questionNotes:store.questionNotes,presentationTabId:store.presentationTabId,slide:store.slide,totalEvents:store.events.length,events:[...store.events].reverse().map(e=>{const pid=e.participantId||identify(store,e.author,e.authorMeetId);return {...e,participantId:pid,inactive:store.session.participants.find(p=>p.id===pid)?.active===false,manual:!!store.manual[e.qid+'|'+pid]};}),unknown:[...new Set(store.events.filter(e=>!e.ignored&&!e.participantId&&!identify(store,e.author,e.authorMeetId)&&store.aliases[aliasKey(e.author)]!=='ignore').map(e=>e.author))]};
  }
  function importData(data){
    const full=data?.kind==='matmov-extension-backup',source=full?data.store:null;
    const store=fresh(),s=structuredClone(Core.validate(full?source?.session:data));
    for(const r of s.rounds)if(r.closedAt===null)r.closedAt=Math.max(Date.now(),r.openedAt);
    s.active=null;store.session=s;
    if(!full){for(const [qid,rows] of Object.entries(s.records))for(const pid of Object.keys(rows))store.manual[qid+'|'+pid]=true;return store;}
    if(source.schema!==1||!Array.isArray(source.events)||source.events.length>5000||!Array.isArray(source.receipts)||source.receipts.length>10000)throw Error('Backup inválido.');
    const ids=new Set(),pids=new Set(s.participants.map(p=>p.id));
    for(const e of source.events){
      const q=Core.question(e.qid);
      if(!e||typeof e.id!=='string'||!/^[-\w:]{1,180}$/.test(e.id)||ids.has(e.id)||(e.qid!==null&&!q)||typeof e.author!=='string'||!e.author.trim()||e.author.length>100||typeof e.text!=='string'||e.text.length>20000||!Number.isFinite(e.observedAt)||(e.part!=null&&(!Number.isInteger(e.part)||e.part<0||e.part>2)))throw Error('Mensagem inválida no backup.');
      if(e.participantId&&!pids.has(e.participantId))throw Error('Participante desconhecido no backup.');
      if(e.reviewed&&(!q||!Array.isArray(e.forced)||e.forced.length!==q.parts.length||e.forced.some(v=>typeof v!=='boolean')))throw Error('Revisão inválida.');
      if(e.authorMeetId!=null&&(typeof e.authorMeetId!=='string'||e.authorMeetId.length>500))throw Error('Identificador do Meet inválido.');
      ids.add(e.id);store.events.push({id:e.id,order:store.events.length,qid:e.qid,author:e.author,authorMeetId:e.authorMeetId||null,text:e.text,observedAt:e.observedAt,part:e.part??null,roundId:e.roundId==null?null:String(e.roundId),displayTime:String(e.displayTime||'').slice(0,30),quality:e.quality==='live'?'live':'uncertain',reason:String(e.reason||'').slice(0,200),reviewed:!!e.reviewed,ignored:!!e.ignored,...(e.participantId?{participantId:e.participantId}:{}),...(e.reviewed?{forced:e.forced}: {})});
      const restored=store.events.at(-1);
      for(const key of ['questionContext','contextSource','slideIndex','cardIndex','truncated','reviewedAt','legacy'])if(e[key]!==undefined){if(JSON.stringify(e[key]).length>20000)throw Error('Contexto muito grande.');restored[key]=structuredClone(e[key]);}
    }
    if(source.receipts.some(id=>typeof id!=='string'||!/^[-\w:]{1,180}$/.test(id)))throw Error('Recibos inválidos.');
    store.receipts=[...new Set(source.receipts)];
    for(const [key,value] of Object.entries(source.aliases||{})){if(!key.startsWith('name:')||key.length>110||(value!=='ignore'&&!pids.has(value)))throw Error('Associação inválida.');store.aliases[key]=value;}
    for(const [key,value] of Object.entries(source.manual||{})){const [qid,pid]=key.split('|');if(!Core.question(qid)||!pids.has(pid)||value!==true)throw Error('Correção manual inválida.');store.manual[key]=true;}
    if(source.capture?.selectors){for(const key of Object.keys(DEFAULT_SELECTORS)){const value=source.capture.selectors[key];if(typeof value!=='string'||!value.trim()||value.length>200)throw Error('Seletores inválidos no backup.');store.capture.selectors[key]=value;}}
    if(source.capture?.ignoredNames){if(!Array.isArray(source.capture.ignoredNames)||source.capture.ignoredNames.length>50||source.capture.ignoredNames.some(n=>typeof n!=='string'||n.length>100))throw Error('Nomes ignorados inválidos.');store.capture.ignoredNames=source.capture.ignoredNames;}
    if(source.roster?.identities){if(Object.keys(source.roster.identities).length>1500)throw Error('Identidades em excesso.');for(const [key,pid] of Object.entries(source.roster.identities)){if(!key.startsWith('meet:')||key.length>1000||!pids.has(pid))throw Error('Identidade inválida.');store.roster.identities[key]=pid;}}
    for(const [qid,note] of Object.entries(source.questionNotes||{})){if(!Core.question(qid)||typeof note!=='string'||note.length>4000)throw Error('Contexto da pergunta inválido.');store.questionNotes[qid]=note;}
    store.captureMode=source.captureMode;upgrade(store);return recalculate(store);
  }
  function exportMessages(store){
    return {schema:'matmov-message-context',version:1,exportedAt:new Date().toISOString(),session:{id:store.session.id,title:store.session.title,createdAt:store.session.createdAt},interpretation:'Mensagens são candidatas. A rodada indica contexto temporal, não prova que o texto seja resposta. Nenhuma inferência LLM foi executada.',questions:Core.QUESTIONS.map(q=>questionContext(store,q.id)),participants:store.session.participants.map(p=>({id:p.id,name:p.name,active:p.active!==false})),rounds:structuredClone(store.session.rounds),messages:store.events.map(e=>{
      const pid=e.participantId||identify(store,e.author,e.authorMeetId),round=store.session.rounds.find(r=>r.id===e.roundId);
      return {id:e.id,author:e.author,participantId:pid,participantActive:pid?store.session.participants.find(p=>p.id===pid)?.active!==false:null,text:e.text,authorMeetId:typeof e.authorMeetId==='string'&&e.authorMeetId.length<=500?e.authorMeetId:null,truncated:!!e.truncated,observedAt:e.observedAt,displayTime:e.displayTime,temporalQuality:e.quality,roundId:e.roundId,candidateQuestionId:round?.qid||null,questionContext:e.questionContext||null,contextSource:e.contextSource||'legacy-unavailable',presentation:{slideIndex:e.slideIndex??null,cardIndex:e.cardIndex??null},humanReview:{isAnswer:e.ignored?false:e.reviewed?true:null,questionId:e.reviewed&&!e.ignored?e.qid:null,correctComponents:e.reviewed&&!e.ignored?e.forced:null,reviewedAt:e.reviewedAt||null},manualRecord:e.qid&&pid?store.session.records[e.qid]?.[pid]||null:null};
    })};
  }
  return {fresh,upgrade,ingest,patch,review,associate,recalculate,snapshot,identify,importData,syncRoster,questionContext,exportMessages,DEFAULT_SELECTORS};
})();
if(typeof module!=='undefined'&&module.exports)module.exports=MatMovEngine;
