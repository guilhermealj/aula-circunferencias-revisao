'use strict';
const MatMovQuestions=(()=>{
  const prompts={
    Q1:'Diga um objeto próximo de você e qual parte dele lembra uma circunferência. Resposta aberta, sem gabarito numérico.',
    Q2:'Uma circunferência tem raio 4 cm. Quanto mede seu diâmetro? Se o diâmetro é 12 cm, quanto mede o raio?',
    Q3:'Uma circunferência tem raio 5 cm. Qual é o comprimento do seu contorno? Dê a resposta exata ou uma aproximação com a hipótese sobre pi.',
    Q4:'Parte a: converta 60 graus para radianos. Parte b: converta 5pi/6 radianos para graus.',
    Q5:'No cinema dos ângulos, A e B fixam um arco observado de 120 graus e P se move no arco oposto. Depois de experimentar: o inscrito aumenta, diminui ou fica constante? Quanto mede? Que condição foi mantida?',
    Q6:'Apostila, exercício 1. Um central de 4x+10 graus e um inscrito de 3x-10 graus observam o mesmo arco AB. Encontre x e a medida angular do arco AB. O pedido final não é apenas x.',
    Q7:'Apostila, exercício 5. AB é diâmetro; C está em uma das semicircunferências; o inscrito BAC mede 40 graus. Qual é a medida do arco menor AC nessa semicircunferência?',
    Q8:'Apostila, exercício 7. PB e PC são tangentes à circunferência de centro O. O inscrito BVC mede 46 graus e observa o arco menor BC. Determine o central BOC e o circunscrito BPC.',
    Q9:'Saída individual: 1) um inscrito observa um arco de 140 graus: quanto mede? 2) converta 90 graus para radianos. 3) duas tangentes determinam um menor central de 120 graus: quanto mede o circunscrito?'
  };
  const get=qid=>prompts[qid]?{catalogVersion:'aula12-2026-v1',qid,prompt:prompts[qid]}:null;
  return {get};
})();
if(typeof module!=='undefined'&&module.exports)module.exports=MatMovQuestions;
