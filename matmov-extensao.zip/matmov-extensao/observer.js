/* Lê somente o DOM visível do chat. Não envia mensagens à reunião. */
(()=>{
  'use strict';
  let config={enabled:false},seenNodes=new WeakMap(),seen=new Set(),pending=[],sending=false,scheduled=false,previousBlocks=0,lastObserved=null,error='',persistentError='',generation=0,remounted=false;
  const docId=crypto.randomUUID();let serial=0;
  const defaults={block:'.Ss4fHf',author:'.poVWob',time:'.MuzmKe',text:'[jsname="dTKtvb"]'};
  const read=el=>(el?.innerText??el?.textContent??'').trim();
  let rosterBusy=false,rosterSignature='';
  function extractRoster(){
    const found=new Map();
    for(const node of document.querySelectorAll('[data-participant-id]')){
      if(node.closest('[aria-hidden="true"], [hidden]'))continue;
      // Seletores conhecidos primeiro; depois alternativas para quando o Meet muda as classes.
      const own=el=>el&&el.closest('[data-participant-id]')===node;
      const nameNode=node.matches('[data-self-name]')?node:[...node.querySelectorAll('[data-self-name], .zWGUib, [jsname="xvfV4b"]')].find(own);
      const fallback=[...node.querySelectorAll('span.notranslate')].find(el=>own(el)&&read(el));
      const raw=nameNode?(nameNode.getAttribute('data-self-name')||read(nameNode)):fallback?read(fallback):node.getAttribute('role')==='listitem'?node.getAttribute('aria-label')||'':'';
      const name=raw.split('\n')[0].replace(/\s*\((?:voc[eê]|you)\)\s*$/i,'').trim();
      const id=node.getAttribute('data-participant-id');
      if(!id||id.length>500||!name||name.length>100)continue;
      found.set(id,{id,name});if(found.size>=500)break;
    }
    return [...found.values()];
  }
  async function syncPeople(){
    if(config.tabId==null||rosterBusy)return;
    const entries=extractRoster(),signature=JSON.stringify(entries);
    if(signature===rosterSignature)return;
    rosterBusy=true;
    try{const result=await chrome.runtime.sendMessage({type:'ROSTER',entries});if(result?.ok)rosterSignature=signature;else error=result?.error||'Falha ao ler participantes.';}catch(e){error=e.message;}finally{rosterBusy=false;}
  }
  function extract(){
    const selectors=config.selectors||defaults,rows=[],blocks=[...document.querySelectorAll(selectors.block)],counts=new Map();
    for(const block of blocks){
      const authorNode=block.querySelector(selectors.author);
      const identityNode=authorNode?.closest('[data-participant-id]')||block.closest('[data-participant-id]');
      const authorMeetId=identityNode?.getAttribute('data-participant-id')||null;
      const author=read(authorNode),displayTime=read(block.querySelector(selectors.time));
      for(const node of block.querySelectorAll(selectors.text)){
        const text=read(node);if(!author||!text)continue;
        const base=JSON.stringify([authorMeetId,author,displayTime,text]),ordinal=counts.get(base)||0;counts.set(base,ordinal+1);
        rows.push({node,author,authorMeetId,text,displayTime,signature:base+'|'+ordinal});
      }
    }
    return {rows,blocks:blocks.length};
  }
  function freshTime(text){
    const m=text.match(/^(\d{1,2}):(\d{2})(?:\s*([ap])\.?m\.?)?$/i);if(!m)return false;
    let h=+m[1];if(m[3])h=h%12+(m[3].toLowerCase()==='p'?12:0);
    if(h>23||+m[2]>59)return false;
    const now=new Date(),minute=now.getHours()*60+now.getMinutes(),stamp=h*60+(+m[2]);return (minute-stamp+1440)%1440<=1;
  }
  function scan(baseline=false){
    let sample;
    try{sample=extract();error='';}catch(e){error='Seletor inválido: '+e.message;return;}
    const now=Date.now();
    for(const row of sample.rows){
      const old=seenNodes.get(row.node),known=seen.has(row.signature);seenNodes.set(row.node,row.signature);seen.add(row.signature);
      if(old===row.signature||known||baseline||!config.enabled)continue;
      if(pending.length>=200){persistentError='Fila cheia: algumas mensagens não foram coletadas. Confira o chat manualmente e aguarde a gravação.';continue;}
      lastObserved=now;
      pending.push({id:docId+':'+(++serial),author:row.author.slice(0,100),authorMeetId:row.authorMeetId,text:row.text.slice(0,20000),truncated:row.text.length>20000,displayTime:row.displayTime,observedAt:now,roundId:config.round?.id||null,slideIndex:config.slideIndex??null,cardIndex:config.cardIndex??null,quality:previousBlocks>0&&!remounted&&!old&&freshTime(row.displayTime)&&row.author.length<=100&&row.text.length<=20000?'live':'uncertain'});
    }
    previousBlocks=sample.blocks;
    remounted=false;
    // Ao atingir este limite, a captura é pausada localmente sem reciclar assinaturas.
    if(seen.size>15000){config.enabled=false;persistentError='Histórico grande: exporte, pause e recarregue a reunião.';}
    flush();return {blocks:sample.blocks,texts:sample.rows.length};
  }
  function apply(next){
    if(!next)return;
    const reset=config.resetToken!==next.resetToken;
    const baseline=reset||config.enabled!==next.enabled||config.round?.id!==next.round?.id;
    if(reset){generation++;pending=[];seenNodes=new WeakMap();seen=new Set();rosterSignature='';}
    config=next;if(baseline)scan(true);
  }
  async function flush(){
    if(sending||!pending.length||config.tabId==null)return;
    sending=true;const batch=pending.slice(0,20),stamp=generation;
    try{
      const result=await chrome.runtime.sendMessage({type:'CAPTURE',events:batch});
      if(!result?.ok)throw Error(result?.error||'Sem confirmação de gravação.');
      if(stamp===generation){const ack=new Set(result.ack);pending=pending.filter(e=>!ack.has(e.id));apply(result.config);if(result.limit)error='Limite local atingido. Exporte a sessão antes de continuar.';}
    }catch(e){error='Gravação pendente: '+e.message;}
    finally{sending=false;}
  }
  async function heartbeat(){
    try{
      const result=await chrome.runtime.sendMessage({type:'OBSERVER_HELLO'});if(!result?.ok)throw Error(result?.error||'Extensão indisponível.');apply(result.config);
      if(config.tabId!=null){const health=scan()||{blocks:0,texts:0};await chrome.runtime.sendMessage({type:'HEALTH',health:{...health,pending:pending.length,lastObserved,error:persistentError||error}});}
      await syncPeople();
    }catch(e){error=e.message;}
  }
  chrome.runtime.onMessage.addListener((m,_sender,respond)=>{if(m?.type==='CONFIG'){apply(m.config);respond({ok:true});}if(m?.type==='SCAN_ROSTER')respond({ok:true,entries:extractRoster()});});
  scan(true);
  new MutationObserver(records=>{
    try{for(const record of records)for(const node of record.removedNodes)if(node.nodeType===1&&(node.matches((config.selectors||defaults).block)||node.querySelector((config.selectors||defaults).block)))remounted=true;}catch{}
    if(scheduled)return;scheduled=true;setTimeout(()=>{scheduled=false;scan();syncPeople();},100);
  }).observe(document.documentElement,{childList:true,subtree:true,characterData:true});
  setInterval(()=>{flush();},1500);
  setInterval(heartbeat,8000);
  heartbeat();
})();
