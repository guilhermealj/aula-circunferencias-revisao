// O token é apenas de pareamento local. A chave OpenAI nunca entra no navegador.
const MatMovLive=(()=>{
  const KEY='matmov-aula12-local-link-v1',ANALYSIS_KEY='matmov-aula12-local-analysis-v1',URL='http://127.0.0.1:8766';
  let sending=false,last=0;
  async function settings(){return (await chrome.storage.local.get(KEY))[KEY]||{enabled:false,token:'',error:''};}
  async function configure(token,enabled){
    if(enabled&&!/^[\w-]{40,80}$/.test(token))throw Error('Código de pareamento inválido. Copie do painel local.');
    await chrome.storage.local.set({[KEY]:{enabled:!!enabled,token:enabled?token:'',error:'',lastSync:null}});
    if(chrome.alarms){if(enabled)await chrome.alarms.create('matmov-local-sync',{periodInMinutes:.5});else await chrome.alarms.clear('matmov-local-sync');}
  }
  function payload(s){return {sessionId:s.session.id,slide:s.slide,slideAt:s.slideAt||null,cardIndex:s.cardIndex,
    extraQuestion:s.extraQuestion||null,extraRevealed:!!s.extraRevealed,capture:s.capture.enabled,visibleContext:s.visibleContext||'',participants:s.session.participants,
    revealed:s.revealed||[],messages:s.events.map(e=>({id:e.id,participantId:e.participantId||MatMovEngine.identify(s,e.author,e.authorMeetId),
      author:e.author,authorMeetId:e.authorMeetId||null,text:e.text,observedAt:e.observedAt,quality:e.quality,slideIndex:e.slideIndex,cardIndex:e.cardIndex,ignored:!!e.ignored}))};}
  async function sync(s,force=false){
    if(sending||!force&&Date.now()-last<2000)return;
    const cfg=await settings();if(!cfg.enabled)return;
    sending=true;last=Date.now();
    try{
      const response=await fetch(URL+'/api/sync',{method:'POST',headers:{'Content-Type':'application/json','Authorization':'Bearer '+cfg.token},body:JSON.stringify(payload(s)),signal:AbortSignal.timeout(6000)});
      if(!response.ok)throw Error('Serviço local HTTP '+response.status+'. Confira o pareamento.');
      const result=await response.json();
      const current=await settings();if(current.token!==cfg.token||!current.enabled)return;
      if(s.presentationTabId!==null)await chrome.tabs.sendMessage(s.presentationTabId,{type:'LESSON_MESSAGE',kind:'live-mode',payload:{enabled:result.localMode===true}}).catch(()=>{});
      // Resultado da análise automática por mensagem, exibido no painel (separado do registro manual).
      const analysis=result.analysis&&typeof result.analysis==='object'?result.analysis:{};
      await chrome.storage.local.set({[KEY]:{...cfg,error:'',lastSync:Date.now()},[ANALYSIS_KEY]:{sessionId:s.session.id,at:Date.now(),messages:analysis}});
    }catch(e){const current=await settings();if(current.token===cfg.token&&current.enabled)await chrome.storage.local.set({[KEY]:{...cfg,error:e.message||'Serviço local indisponível.'}});}
    finally{sending=false;}
  }
  async function chart(s){
    const cfg=await settings();if(!cfg.enabled)throw Error('Conecte o assistente local no controle da extensão para ver o gráfico.');
    const response=await fetch(URL+'/api/chart',{method:'POST',headers:{'Content-Type':'application/json',Authorization:'Bearer '+cfg.token},body:JSON.stringify({sessionId:s.session.id}),signal:AbortSignal.timeout(6000)});
    const data=await response.json();if(!response.ok)throw Error(data.error||'Não foi possível carregar o gráfico.');
    return data;
  }
  // Abre o painel já pareado: o código vai no fragmento (#), que não é enviado em requisições HTTP.
  async function dashboardURL(){const cfg=await settings();return URL+'/'+(cfg.enabled&&cfg.token?'#'+cfg.token:'');}
  async function info(){const cfg=await settings();return {enabled:cfg.enabled,error:cfg.error,lastSync:cfg.lastSync};}
  return {configure,sync,info,payload,chart,dashboardURL,URL,ANALYSIS_KEY};
})();
if(typeof module!=='undefined'&&module.exports)module.exports=MatMovLive;
