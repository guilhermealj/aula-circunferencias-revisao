'use strict';
importScripts('core.js','questions.js','engine.js','live.js');
const STORE_KEY='matmov-aula12-extension-v1',ARCHIVE_KEY='matmov-aula12-previous-v1';
let current=null,queue=Promise.resolve();
const panelURL=chrome.runtime.getURL('panel.html');
function isLesson(url){try{const u=new URL(url);return (u.protocol==='file:'||(['localhost','127.0.0.1'].includes(u.hostname)&&u.protocol==='http:')||(u.origin==='https://guilhermealj.github.io'&&u.pathname==='/aula-circunferencias-revisao/aula12.html'))&&decodeURIComponent(u.pathname).endsWith('/aula12.html')&&!u.searchParams.has('modo');}catch{return false;}}
function isMeet(url){try{const u=new URL(url);return u.origin==='https://meet.google.com';}catch{return false;}}
async function load(){if(current)return current;const found=(await chrome.storage.local.get(STORE_KEY))[STORE_KEY];if(found){if(found.schema!==1)throw Error('Versão de sessão desconhecida.');LessonCore.validate(found.session);current=MatMovEngine.upgrade(found);}else current=MatMovEngine.fresh();return current;}
function config(s){return {enabled:s.capture.enabled,tabId:s.capture.tabId,resetToken:s.capture.resetToken,selectors:s.capture.selectors,slideIndex:s.slide,cardIndex:s.cardIndex,round:s.session.rounds.find(r=>r.id===s.session.active)||null};}
async function publish(s){
  await chrome.runtime.sendMessage({type:'STATE_CHANGED',revision:s.revision}).catch(()=>{});
  if(s.capture.tabId!==null)await chrome.tabs.sendMessage(s.capture.tabId,{type:'CONFIG',config:config(s)}).catch(()=>{});
}
async function save(next){
  next.revision=(current?.revision||0)+1;
  LessonCore.validate(next.session);
  // ACK somente depois da escrita. O worker pode ser suspenso logo após esta linha.
  await chrome.storage.local.set({[STORE_KEY]:next});current=next;
  await publish(next);MatMovLive.sync(next).catch(()=>{});return MatMovEngine.snapshot(next);
}
function endRound(s){const r=s.session.rounds.find(r=>r.id===s.session.active);if(r)r.closedAt=Math.max(Date.now(),r.openedAt);s.session.active=null;}
function toggleRound(s){
  const qid=s.session.selected,active=s.session.rounds.find(r=>r.id===s.session.active);endRound(s);
  if(active?.qid===qid)return;
  if(s.session.omitted.includes(qid))throw Error('Esta questão está marcada como não aplicada.');
  if(s.session.rounds.length>=1000)throw Error('Limite de rodadas atingido. Exporte e inicie outra sessão.');
  const r={id:LessonCore.uid(),qid,openedAt:Date.now(),closedAt:null,context:MatMovEngine.questionContext(s,qid)};s.session.rounds.push(r);s.session.active=r.id;s.session.complete=s.session.complete.filter(id=>id!==qid);
}
async function openPanel(){
  const tabs=(await chrome.tabs.query({})).filter(tab=>tab.url===panelURL);
  if(tabs.length){await chrome.tabs.update(tabs[0].id,{active:true});await chrome.windows.update(tabs[0].windowId,{focused:true});return;}
  await chrome.windows.create({url:panelURL,type:'popup',width:1240,height:900});
}
async function lessonSend(s,type,payload){
  if(s.presentationTabId===null)throw Error('Selecione a guia da aula no controle.');
  const tab=await chrome.tabs.get(s.presentationTabId);if(!isLesson(tab.url))throw Error('A guia selecionada não está mais na aula.');
  let response;try{response=await chrome.tabs.sendMessage(tab.id,{type:'LESSON_MESSAGE',kind:type,payload});}catch{throw Error('Recarregue a aula. Para arquivo local, habilite o acesso a URLs de arquivo na extensão.');}
  if(!response?.ok)throw Error('A aula não confirmou o recebimento. Recarregue aula12.html.');
}
// Eco visual do chat na aula (tela compartilhada). Só mensagens novas, já gravadas, de participantes ativos.
function chatEcho(s,stored){
  const messages=stored.filter(e=>{const pid=e.participantId||MatMovEngine.identify(s,e.author,e.authorMeetId);return s.session.participants.find(p=>p.id===pid)?.active!==false;}).map(e=>({author:e.author,text:e.text.slice(0,500)}));
  if(!messages.length||s.presentationTabId===null)return;
  chrome.tabs.get(s.presentationTabId).then(tab=>isLesson(tab.url)?chrome.tabs.sendMessage(tab.id,{type:'LESSON_MESSAGE',kind:'chat',payload:{messages}}):null).catch(()=>{});
}
async function dispatch(m,sender){
  if(!m||typeof m.type!=='string')throw Error('Mensagem inválida.');
  const s=await load(),native=sender.url===panelURL&&!sender.tab?.url?.startsWith('https://'),meet=sender.frameId===0&&isMeet(sender.url)&&sender.tab?.id===s.capture.tabId;
  const lesson=sender.frameId===0&&isLesson(sender.url)&&Number.isInteger(sender.tab?.id);
  if(m.type==='OBSERVER_HELLO'){
    if(!isMeet(sender.url)||sender.frameId!==0)throw Error('Origem inválida.');
    return {config:meet?config(s):{enabled:false,tabId:null}};
  }
  if(m.type==='ROSTER'){
    if(!meet)throw Error('Esta guia do Meet não está vinculada.');
    const next=structuredClone(s),result=MatMovEngine.syncRoster(next,m.entries);await save(next);return result;
  }
  if(m.type==='CAPTURE'||m.type==='HEALTH'){
    if(!meet)throw Error('Esta guia do Meet não está vinculada.');
    const next=structuredClone(s);
    if(m.type==='HEALTH'){
      const h=m.health||{};next.capture.health={at:Date.now(),blocks:Math.max(0,Math.min(5000,Number(h.blocks)||0)),texts:Math.max(0,Math.min(10000,Number(h.texts)||0)),pending:Math.max(0,Number(h.pending)||0),lastObserved:Number(h.lastObserved)||null,error:String(h.error||'').slice(0,300)};
      await save(next);return {config:config(next)};
    }
    if(!Array.isArray(m.events)||m.events.length>40)throw Error('Lote inválido.');
    const ack=[],stored=[];
    for(const event of m.events){
      if(next.receipts.includes(event.id)){ack.push(event.id);continue;}
      // Um evento lido antes de pausar ainda pode estar aguardando o ACK.
      // A rodada e o horário originais determinam sua elegibilidade.
      const receipt=MatMovEngine.ingest(next,event);if(receipt.limit)break;ack.push(event.id);
      if(receipt.stored)stored.push(next.events.at(-1));
    }
    // Mantém espaço para backup e preferências dentro da quota local do Chrome.
    if(new TextEncoder().encode(JSON.stringify(next)).length>4_000_000){const limited=structuredClone(s);limited.capture.enabled=false;limited.capture.health={...limited.capture.health,at:Date.now(),error:'Armazenamento próximo do limite. Exporte a sessão e abra outra.'};await save(limited);return {ack:[],config:config(limited),limit:true};}
    await save(next);chatEcho(next,stored);return {ack,config:config(next),limit:!next.capture.enabled};
  }
  if(m.type.startsWith('LESSON_')){
    if(!lesson)throw Error('Guia de apresentação inválida.');
    if(m.type==='LESSON_HELLO')return {available:true,bound:s.presentationTabId===sender.tab.id};
    if(m.type==='LESSON_OPEN'){await openPanel();return {opened:true};}
    if(m.type==='LESSON_CHART'){
      if(s.presentationTabId!==sender.tab.id)throw Error('Vincule esta aba da aula no controle da extensão.');
      return {chart:await MatMovLive.chart(s)};
    }
    if(s.presentationTabId!==sender.tab.id)return {bound:false};
    if(m.type==='LESSON_SLIDE'){
      if(!Number.isInteger(m.index)||m.index<0||m.index>23)throw Error('Tela inválida.');
      const cardIndex=m.index===15&&Number.isInteger(m.cardIndex)&&m.cardIndex>=0&&m.cardIndex<3?m.cardIndex:null;
      const extraQuestion=/^R(0[1-9]|1[0-6])$/.test(m.extraQuestion||'')?m.extraQuestion:null,extraRevealed=!!extraQuestion&&m.extraRevealed===true;
      const visibleContext=typeof m.visibleContext==='string'?m.visibleContext.slice(0,20000):'';
      if(s.slide===m.index&&s.cardIndex===cardIndex&&s.visibleContext===visibleContext&&s.extraQuestion===extraQuestion&&s.extraRevealed===extraRevealed)return {bound:true};const next=structuredClone(s);if(s.slide!==m.index||s.cardIndex!==cardIndex||!s.slideAt)next.slideAt=Date.now();next.slide=m.index;next.cardIndex=cardIndex;next.visibleContext=visibleContext;next.extraQuestion=extraQuestion;next.extraRevealed=extraRevealed;await save(next);return {bound:true};
    }
    if(m.type==='LESSON_REVEAL'){
      if(!LessonCore.question(m.qid))throw Error('Questão inválida.');
      const next=structuredClone(s);next.revealed??=[];next.revealed.push({qid:m.qid,at:Date.now(),slide:next.slide});next.revealed=next.revealed.slice(-1000);
      const active=s.session.rounds.find(r=>r.id===s.session.active);
      if(active&&active.qid===m.qid)endRound(next);await save(next);return {bound:true};
    }
    throw Error('Operação desconhecida.');
  }
  if(!native)throw Error('Operação disponível somente no controle da extensão.');
  if(m.type==='LIVE_INFO')return {live:await MatMovLive.info()};
  if(m.type==='LIVE_CONFIG'){await MatMovLive.configure(m.token||'',m.enabled);await MatMovLive.sync(s,true);return {live:await MatMovLive.info()};}
  if(m.type==='LIVE_OPEN'){await chrome.tabs.create({url:await MatMovLive.dashboardURL()});return {live:await MatMovLive.info()};}
  if(m.type==='LIVE_SYNC'){await MatMovLive.sync(s,true);return {live:await MatMovLive.info()};}
  if(m.type==='GET')return {snapshot:MatMovEngine.snapshot(s)};
  if(m.type==='TABS'){
    const tabs=await chrome.tabs.query({url:['https://meet.google.com/*','http://localhost/*','http://127.0.0.1/*','file:///*','https://guilhermealj.github.io/aula-circunferencias-revisao/*']});
    const pageAccess=await chrome.permissions.contains({origins:['http://localhost/*','http://127.0.0.1/*']});
    return {version:chrome.runtime.getManifest().version,pageAccess,meet:tabs.filter(t=>isMeet(t.url)).map(t=>({id:t.id,title:t.title||t.url,url:t.url})),lesson:tabs.filter(t=>isLesson(t.url)).map(t=>({id:t.id,title:t.title||t.url,url:t.url}))};
  }
  if(m.type==='EXPORT')return {backup:{kind:'matmov-extension-backup',version:1,exportedAt:Date.now(),store:s}};
  if(m.type==='EXPORT_MESSAGES')return {dataset:MatMovEngine.exportMessages(s)};
  if(m.type==='PROJECT'){
    if(s.session.active)throw Error('Encerre a rodada antes de projetar.');
    if(!['collective','ranking','lines'].includes(m.mode))throw Error('Visualização inválida.');
    if(m.mode==='lines'&&s.session.participants.filter(p=>p.publish&&p.active!==false).length>4)throw Error('Selecione até quatro rótulos públicos.');
    await lessonSend(s,'public',LessonCore.publicData(s.session,m.mode));return {sent:true};
  }
  if(m.type==='HIDE'){await lessonSend(s,'hide-public',{});return {sent:true};}
  if(m.type==='FOCUS_LESSON'){if(s.presentationTabId===null)throw Error('Selecione uma apresentação.');const t=await chrome.tabs.update(s.presentationTabId,{active:true});await chrome.windows.update(t.windowId,{focused:true});return {opened:true};}
  if(m.type==='IMPORT'||m.type==='NEW'||m.type==='RESTORE_PREVIOUS'){
    let next;
    if(m.type==='IMPORT')next=MatMovEngine.importData(m.data);
    else if(m.type==='NEW')next=MatMovEngine.fresh();
    else {const old=(await chrome.storage.local.get(ARCHIVE_KEY))[ARCHIVE_KEY];if(!old)throw Error('Não há sessão anterior.');next=MatMovEngine.importData({kind:'matmov-extension-backup',store:old});}
    next.presentationTabId=s.presentationTabId;
    // Uma sessão anterior permanece recuperável, inclusive depois de reiniciar.
    await chrome.storage.local.set({[ARCHIVE_KEY]:s});
    if(s.capture.tabId!==null)await chrome.tabs.sendMessage(s.capture.tabId,{type:'CONFIG',config:{enabled:false,tabId:null}}).catch(()=>{});
    return {snapshot:await save(next)};
  }
  const next=structuredClone(s);
  if(m.type==='PATCH')MatMovEngine.patch(next,m.before,m.after);
  else if(m.type==='PARTICIPANT_ACTIVE'){
    const p=next.session.participants.find(p=>p.id===m.pid);if(!p||typeof m.active!=='boolean')throw Error('Participante inválido.');
    p.active=m.active;if(!p.active)p.publish=false;next.session.complete=[];MatMovEngine.recalculate(next);
  }
  else if(m.type==='READ_ROSTER'){
    if(next.capture.tabId===null)throw Error('Vincule o Meet primeiro.');
    const result=await chrome.tabs.sendMessage(next.capture.tabId,{type:'SCAN_ROSTER'}).catch(()=>null);
    if(!result?.ok||!Array.isArray(result.entries))throw Error('Recarregue o Meet após atualizar a extensão. Abra o painel Pessoas.');
    MatMovEngine.syncRoster(next,result.entries);
  }
  else if(m.type==='QUESTION_NOTE'){
    if(!LessonCore.question(m.qid)||typeof m.note!=='string'||m.note.length>4000)throw Error('Contexto inválido.');
    next.questionNotes[m.qid]=m.note;
  }
  else if(m.type==='ROUND')toggleRound(next);
  else if(m.type==='ASSOCIATE')MatMovEngine.associate(next,m.author,m.participantId,!!m.create);
  else if(m.type==='REVIEW')MatMovEngine.review(next,m.review);
  else if(m.type==='UNLOCK'){
    if(!LessonCore.question(m.qid)||!next.session.participants.some(p=>p.id===m.pid))throw Error('Registro inválido.');
    delete next.manual[m.qid+'|'+m.pid];next.session.complete=next.session.complete.filter(q=>q!==m.qid);MatMovEngine.recalculate(next);
  }
  else if(m.type==='BIND_MEET'){
    if(!Number.isInteger(m.tabId))throw Error('Selecione uma guia do Meet.');const tab=await chrome.tabs.get(m.tabId);if(!isMeet(tab.url))throw Error('Esta guia não é do Meet.');
    endRound(next);next.capture={...next.capture,tabId:tab.id,meetUrl:tab.url,enabled:false,health:null,resetToken:LessonCore.uid()};
    if(s.capture.tabId!==null&&s.capture.tabId!==tab.id)await chrome.tabs.sendMessage(s.capture.tabId,{type:'CONFIG',config:{enabled:false,tabId:null}}).catch(()=>{});
  }
  else if(m.type==='CAPTURE_SWITCH'){
    if(m.enabled){if(next.capture.tabId===null)throw Error('Vincule uma guia do Meet.');const t=await chrome.tabs.get(next.capture.tabId);if(t.url!==next.capture.meetUrl)throw Error('A reunião mudou. Vincule novamente.');}
    next.capture.enabled=!!m.enabled;if(!m.enabled)endRound(next);
  }
  else if(m.type==='BIND_LESSON'){
    if(!Number.isInteger(m.tabId))throw Error('Selecione uma guia da aula.');const tab=await chrome.tabs.get(m.tabId);if(!isLesson(tab.url))throw Error('Abra aula12.html no navegador.');
    const response=await chrome.tabs.sendMessage(tab.id,{type:'BRIDGE_PING'}).catch(()=>null);if(!response?.ok)throw Error('Recarregue a aula e habilite “Permitir acesso a URLs de arquivo”, se necessário.');next.presentationTabId=tab.id;
  }
  else if(m.type==='SELECTORS'){
    for(const key of ['block','author','time','text'])if(typeof m.selectors?.[key]!=='string'||!m.selectors[key].trim()||m.selectors[key].length>200)throw Error('Seletores inválidos.');
    next.capture.selectors=Object.fromEntries(['block','author','time','text'].map(k=>[k,m.selectors[k]]));next.capture.resetToken=LessonCore.uid();next.capture.enabled=false;endRound(next);
  }
  else if(m.type==='IGNORED_NAMES'){
    if(!Array.isArray(m.names)||m.names.length>50||m.names.some(n=>typeof n!=='string'||n.length>100))throw Error('Nomes inválidos.');next.capture.ignoredNames=m.names;
  }
  else throw Error('Operação desconhecida.');
  return {snapshot:await save(next)};
}
function enqueue(fn){const task=queue.then(fn);queue=task.catch(()=>{});return task;}
chrome.runtime.onMessage.addListener((m,sender,respond)=>{
  if(m?.type==='STATE_CHANGED')return false;
  enqueue(()=>dispatch(m,sender)).then(result=>respond({ok:true,...result}),err=>respond({ok:false,error:err.message||String(err)}));return true;
});
chrome.action.onClicked.addListener(()=>openPanel().catch(console.error));
chrome.commands.onCommand.addListener(command=>{if(command==='toggle-round')enqueue(async()=>{const s=structuredClone(await load());toggleRound(s);await save(s);}).catch(console.error);});
chrome.tabs.onRemoved.addListener(id=>enqueue(async()=>{const s=structuredClone(await load());let changed=false;if(s.capture.tabId===id){s.capture.enabled=false;s.capture.tabId=null;endRound(s);changed=true;}if(s.presentationTabId===id){s.presentationTabId=null;changed=true;}if(changed)await save(s);}).catch(console.error));
chrome.tabs.onUpdated.addListener((id,change)=>{if(!change.url)return;enqueue(async()=>{const s=structuredClone(await load());if(id===s.capture.tabId&&change.url!==s.capture.meetUrl){s.capture.enabled=false;s.capture.health=null;endRound(s);await save(s);}}).catch(console.error);});
chrome.runtime.onStartup.addListener(()=>enqueue(async()=>{const s=structuredClone(await load());s.capture.enabled=false;s.capture.tabId=null;s.capture.health=null;s.presentationTabId=null;endRound(s);await save(s);}).catch(console.error));

if(chrome.alarms)chrome.alarms.onAlarm.addListener(alarm=>{if(alarm.name==='matmov-local-sync')enqueue(async()=>MatMovLive.sync(await load(),true)).catch(()=>{});});
